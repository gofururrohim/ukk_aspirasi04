<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion">

    <a class="sidebar-brand d-flex align-items-center justify-content-center">
        <div class="sidebar-brand-icon">
            <i class="fas fa-user-graduate"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Siswa</div>
    </a>

    <hr class="sidebar-divider">

    <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-home"></i>
            <span>dashboard</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="histori.php">
            <i class="fas fa-fw fa-history"></i>
            <span>histori</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="input_aspirasi.php">
            <i class="fas fa-fw fa-edit"></i>
            <span>input aspirasi</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="input_data.php">
            <i class="fas fa-fw fa-edit"></i>
            <span>input data siswa</span>
        </a>
    </li>


    <li class="nav-item">
        <a class="nav-link" href="logout.php">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>logout</span>
        </a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">
</ul>
