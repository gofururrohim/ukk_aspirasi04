<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 shadow">

    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <span class="nav-link text-gray-600 font-weight-bold">
                Pengaduan Sekolah
            </span>
        </li>
    </ul>

</nav>
