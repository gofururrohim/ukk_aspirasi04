<?php
session_start();


if (!isset($_SESSION['nis'])) {
    header("Location: ../index.php");
}
?>

<?php include '../assets/template/header.php'; ?>
<?php include '../assets/template/sidebar_siswa.php'; ?>
<?php include '../assets/template/navbar.php'; ?>


<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800 font-weight-bold">Dashboard Siswa</h1>
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                menu
                            </div>
                            <div class="h5 mb-0 text-gray-1000">
                                iput aspirasi
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-2x text-gray-300"></i>
                        </div>
                    </div>
                    <a href="input_aspirasi.php" class="btn btn-primary btn-sm mt-3">
                        tambah
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                menu
                            </div>
                            <div class="h5 mb-0 text-gray-1000">
                                histori aspirasi
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-2x text-gray-300"></i>
                        </div>
                    </div>
                    <a href="histori.php" class="btn btn-primary btn-sm mt-3">
                        lihat
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                menu
                            </div>
                            <div class="h5 mb-0 text-gray-1000">
                                Data Siswa
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-2x text-gray-300"></i>
                        </div>
                    </div>
                    <a href="input_data.php" class="btn btn-primary btn-sm mt-3">
                        lihat
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="text-right">
        <a href="histori.php" class="btn btn-secondary mt-10">
            <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</div>
<?php include '../assets/template/footer.php'; ?>
