<?php
session_start();
include '../config/koneksi.php';


if (!isset($_SESSION['nis'])) {
    header("Location: ../index.php");
}
?>


<?php include '../assets/template/header.php'; ?>
<?php include '../assets/template/sidebar_siswa.php'; ?>
<?php include '../assets/template/navbar.php'; ?>


<div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800">Input Data Siswa</h1>


        <div class="row justify-content-center">
        <div class="col-lg-8">

            <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-primary text-white">
                        <h6 class="m-0 font-weight-bold">Input Data Siswa</h6>
                    </div>
    
    
                    <div class="card-body">
                        <div class="form-group">
                                <label class="font-weight-bold">nis</label>
                                <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                                <label class="font-weight-bold">kelas</label>
                                <input type="text" class="form-control" required>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">
                                    simpan
                            </button>
                        </div>                
                    </div>
    
            </div>
        </div>
        </div>
</div>

<?php include '../assets/template/footer.php'; ?>
