<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}
?>


<?php include '../assets/template/header.php'; ?>
<?php include '../assets/template/sidebar_admin.php'; ?>
<?php include '../assets/template/navbar.php'; ?>



<?php include '../assets/template/footer.php'; ?>