<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "ukk_aspirasi";
$koneksi = mysqli_connect($host, $user, $pass, $db);                                                                                  

if (!$koneksi) {

    die("Koneksi Tidak Berhasil: " . mysqli_connect_error());
}