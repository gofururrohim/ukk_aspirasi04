<?php include 'assets/template/header.php'; ?> 


<div id="content-wrapper" class="d-flex flex-column">
<div id="content">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow"> 
    <a class="navbar-brand font-weight-bold" href="index.php"> 
        Pengaduan Sekolah 
    </a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarPublic"> 
        <span class="navbar-toggler-icon"></span> 
    </button> 

    <div class="collapse navbar-collapse" id="navbarPublic"> 
        <ul class="navbar-nav ml-auto"> 
            <li class="nav-item"> 
                <a class="btn btn-light text-primary ml-2" href="login.php"> 
                    login
                </a> 
            </li> 
        </ul> 
    </div> 
</nav> 

<div class="container-fluid my-5"> 
    <div class="text-center mb-5"> 
        <h2 class="font-weight-bold">Aplikasi Pengaduan Sarana Sekolah</h2> 
        <p class="text-muted"> 
            Media penyampaian aspirasi siswa terkait sarana dan prasarana sekolah 
        </p> 
    </div> 
    <div class="row text-center"> 
        <div class="col-md-4"> 
            <i class="fas fa-edit fa-3x text-primary mb-3"></i> 
            <h5 class="font-weight-bold">Input Aspirasi</h5> 
            <p>Siswa dapat mengirimkan pengaduan dengan mudah.</p> 
        </div> 
        <div class="col-md-4"> 
            <i class="fas fa-tasks fa-3x text-success mb-3"></i> 
            <h5 class="font-weight-bold">Status & Feedback</h5> 
            <p>Admin menindaklanjuti aspirasi dengan transparan.</p> 
        </div> 
        <div class="col-md-4"> 
            <i class="fas fa-print fa-3x text-warning mb-3"></i> 
            <h5 class="font-weight-bold">Laporan</h5> 
            <p>Laporan pengaduan dapat dicetak oleh admin.</p> 
        </div> 
    </div> 

</div> 
<div class="bg-light py-5"> 
    <div class="container"> 
        <h3 class="text-center mb-3 font-weight-bold">Tentang Aplikasi</h3> 
        <p class="text-center"> 
            Aplikasi ini dibuat untuk mendukung proses pengaduan sarana sekolah 

            agar lebih efektif, efisien, dan terdokumentasi dengan baik. 
        </p> 
    </div> 
</div> 

<?php include 'assets/template/footer.php'; ?>